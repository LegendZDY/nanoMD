# -*- coding: utf-8 -*-
__author__ = "legendzdy@dingtalk.com"
"""
Author: legendzdy@dingtalk.com
Data: 20250217
Description:
function basetools.
"""
import os

def check_path_exists(path):
    return os.path.exists(path)